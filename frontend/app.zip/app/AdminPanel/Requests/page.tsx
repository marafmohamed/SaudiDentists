"use client";
import React, { useEffect, useState } from "react";
import { useApp } from "../../Context";
import Request from "../../Components/SmallComponents/Request";
import Cookies from "js-cookie";
import { RequestData } from "../../Components/SmallComponents/RequestPopup";
import "../styles.css";
export default function Page() {
  const { baseUrl, lang } = useApp();
  const [requests, setRequests] = useState<RequestData[]>([]);
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [isEnglish, setIsEnglish] = useState(lang === "en");
  useEffect(() => {
    setIsEnglish(lang === "en");
  }, [lang]);
  useEffect(() => {
    const getRequest = async () => {
      setLoading(true);
      const token = Cookies.get("admin");
      if (!token) {
        return setLoading(false);
      }
      try {
        const response = await fetch(
          `${baseUrl}/api/requests/getPaginatedRequests?page=${1}&limit=${15}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        const json = await response.json();
        if (!response.ok) {
          console.log(json);
          setLoading(false);
          return json;
        }
        setRequests(json.requests);
        setTotalPages(json.totalPages);
        setLoading(false);
        console.log(json);
      } catch (error) {
        console.log(error);
      }
    };
    getRequest();
  }, []);
  const handlePageClick = async (page: number) => {
    const response = await fetch(
      `${baseUrl}/api/requests/getPaginatedRequests?page=${page}&limit=${15}`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${Cookies.get("admin")}`,
          "Content-Type": "application/json",
        },
      }
    );
    const cc = await response.json();
    if (response.status !== 200) {
      console.log(cc.error);
      return;
    }

    if (cc.error) {
      console.log(cc.error);
      return;
    }
    setTotalPages(cc.totalPages);
    setCurrentPage(page);
    setRequests(cc.requests);
  };

  const renderPageNumbers = () => {
    const pages = [];

    // First page
    pages.push(
      <button
        key={1}
        className={`px-3 py-1 rounded-md mx-1 transition-colors duration-200 ${
          currentPage === 1
            ? "bg-blue-500 text-white"
            : "bg-gray-200 hover:bg-gray-300 text-black"
        }`}
        onClick={() => handlePageClick(1)}
      >
        1
      </button>
    );

    // Ellipsis before the current block
    if (currentPage > 3) {
      pages.push(
        <span key="start-ellipsis" className="px-2">
          ...
        </span>
      );
    }

    // Pages around the current page
    for (
      let i = Math.max(2, currentPage - 1);
      i <= Math.min(totalPages - 1, currentPage + 1);
      i++
    ) {
      pages.push(
        <button
          key={i}
          className={`px-3 py-1 rounded-md mx-1 transition-colors duration-200 ${
            currentPage === i
              ? "bg-blue-500 text-white"
              : "bg-gray-200 hover:bg-gray-300 text-black"
          }`}
          onClick={() => handlePageClick(i)}
        >
          {i}
        </button>
      );
    }

    // Ellipsis after the current block
    if (currentPage < totalPages - 2) {
      pages.push(
        <span key="end-ellipsis" className="px-2">
          ...
        </span>
      );
    }

    // Last page
    if (totalPages > 1) {
      pages.push(
        <button
          key={totalPages}
          className={`px-3 py-1 rounded-md mx-1 transition-colors duration-200 ${
            currentPage === totalPages
              ? "bg-blue-500 text-white"
              : "bg-gray-200 hover:bg-gray-300 text-black"
          }`}
          onClick={() => handlePageClick(totalPages)}
        >
          {totalPages}
        </button>
      );
    }

    return pages;
  };
  return (
    <div className="min-h-[500px] flex flex-col items-center py-8">
      {loading && (
        <div className="loading-container">
          <div className="loader"></div>
        </div>
      )}
      {!loading && requests.length === 0 && (
        <div className="w-full h-[500px] text-bold text-xl flex items-center justify-center ">
          {isEnglish ? "No Requests" : "لا توجد طلبات"}
        </div>
      )}
        {!loading &&
          requests.length > 0 &&
          requests.map((request) => (
            <Request
              key={request._id}
              data={request}
              setDemands={() =>
                setRequests(requests.filter((r) => r._id !== request._id))
              }
            ></Request>
          ))}

      <div className="flex items-center justify-center mt-auto">
        {/* Previous button */}
        <button
          className="bg-[#0D6887] text-white px-3 py-1 rounded-md mx-2 transition-opacity duration-200 disabled:opacity-50"
          onClick={() => handlePageClick(currentPage - 1)}
          disabled={currentPage === 1}
        >
          {"<"}
        </button>

        {/* Page numbers */}
        {renderPageNumbers()}

        {/* Next button */}
        <button
          className="bg-[#0D6887] text-white px-3 py-1 rounded-md mx-2 transition-opacity duration-200 disabled:opacity-50"
          onClick={() => handlePageClick(currentPage + 1)}
          disabled={currentPage === totalPages || totalPages === 0}
        >
          {">"}
        </button>
      </div>
    </div>
  );
}
